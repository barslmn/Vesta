class Pedigree(object):

    """Holds family name Individuals, Unions.
    This class has methods for counting marriages, founders etc."""

    def __init__(self):
        """TODO: to be defined. """
        pass


class Individual(object):

    """Holds attributes for an individual.
    name, sex, DoB, DoD,
    siblings, twins, parents"""

    def __init__(self):
        """TODO: to be defined. """
        pass
        

class Union(object):

    """Holds two individuals and union type"""

    def __init__(self):
        """TODO: to be defined. """
        pass


class Twins(object):

    """Docstring for Twins. """

    def __init__(self):
        """TODO: to be defined. """
        pass
